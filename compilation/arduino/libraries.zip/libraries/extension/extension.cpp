#include <Arduino.h>
#include "extension.h"

extension::extension(){}

void extension::ultrason(byte trig, byte echo){
	pinMode(trig, OUTPUT);
	digitalWrite(trig, LOW);
	pinMode(echo, INPUT);
	trig_pin = trig;
	echo_pin = echo;
}

float extension::ultrason_distance(){
	digitalWrite(trig_pin, HIGH);
	delayMicroseconds(10);
	digitalWrite(trig_pin, LOW);
	return pulseIn(echo_pin, HIGH)/58;
}

void extension::bargraphe(byte dcki, byte di){
	pinMode(dcki, OUTPUT);
	pinMode(di, OUTPUT);
	dcki_pin = dcki;
	di_pin = di;
}

void extension::bargraphe_allumer(byte del){
	unsigned char _state[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	
	del=max(0, min(10, del));
	del *= 8;
	for (byte i=0; i<10; i++) {
		_state[i]=(del>8) ? ~0 : (del>0) ? ~(~0 << byte(del)) : 0;
		del -= 8;
	};
	setData(_state);
}
void extension::sendData(unsigned int data) {
	  for (unsigned char i=0; i < 16; i++){
		unsigned int state=(data&0x8000) ? HIGH : LOW;
		digitalWrite(di_pin, state);
		state=digitalRead(dcki_pin) ? LOW : HIGH;
		digitalWrite(dcki_pin, state);
		data <<= 1;
	  }
	}
	void extension::setData(unsigned char _state[]) {
	  sendData(0x00);
	  for (unsigned char i=0; i<10; i++) sendData(_state[10-i-1]);
	  sendData(0x00);
	  sendData(0x00);
	  digitalWrite(di_pin, LOW);
	  delayMicroseconds(10);
	  for (unsigned char i=0; i<4; i++){
		digitalWrite(di_pin, HIGH);
		digitalWrite(di_pin, LOW);
	  }
	}
void extension::matrice16(byte A4, byte A5){
	pinMode(A4,OUTPUT);
	pinMode(A5,OUTPUT);
	digitalWrite(A4,LOW);
	digitalWrite(A5,LOW);
	sda_pin = A4;
	scl_pin = A5;
}

void extension::matrice16_afficher(byte s[]){
	IIC_start(scl_pin, sda_pin);
	IIC_send(0x40);
	IIC_end(scl_pin, sda_pin);
	IIC_start(scl_pin, sda_pin);
	IIC_send(0xC0);
	for(char i=0; i<16; i++) {
		IIC_send(s[i]);
	}
	IIC_end(scl_pin, sda_pin);
	IIC_start(scl_pin, sda_pin);
	IIC_send(0x8F);
	IIC_end(scl_pin, sda_pin);
}
	void extension::IIC_start(byte scl_pin, byte sda_pin) {
		digitalWrite(scl_pin,LOW);
		delayMicroseconds(3);
		digitalWrite(sda_pin,HIGH);
		delayMicroseconds(3);
		digitalWrite(scl_pin,HIGH);
		delayMicroseconds(3);
		digitalWrite(sda_pin,LOW);
		delayMicroseconds(3);
	}
	void extension::IIC_end(byte scl_pin, byte sda_pin) {
		digitalWrite(scl_pin,LOW);
		delayMicroseconds(3);
		digitalWrite(sda_pin,LOW);
		delayMicroseconds(3);
		digitalWrite(scl_pin,HIGH);
		delayMicroseconds(3);
		digitalWrite(sda_pin,HIGH);
		delayMicroseconds(3);
	}
		void extension::IIC_send(unsigned char send_data) {
		for(char i = 0;i < 8;i++) {
			digitalWrite(scl_pin,LOW);
			delayMicroseconds(3);
			if(send_data & 0x01) {
				digitalWrite(sda_pin,HIGH);
			} else {
				digitalWrite(sda_pin,LOW);
			}
			delayMicroseconds(3);
			digitalWrite(scl_pin,HIGH);
			delayMicroseconds(3);
			send_data = send_data >> 1;
		}
	}
void extension::matrice16_effacer(){
	byte t[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	matrice16_afficher (t);
}

void extension::rvb(byte pinR, byte pinV, byte pinB){
	pinMode(pinR, OUTPUT);
	pinMode(pinV, OUTPUT);
	pinMode(pinB, OUTPUT);
	Rouge_pin = pinR;
	Vert_pin = pinV;
	Bleu_pin = pinB;
}

void extension::rvb_afficher_couleur(byte red, byte green, byte blue){
	analogWrite(Rouge_pin, red);
	analogWrite(Vert_pin, green);
	analogWrite(Bleu_pin, blue);
}

void extension::mp3(){
	
}

