This folder should contain the .cpp and .h files for the library. 

If backward compatibility is needed, source code should be placed in the library root folder and in a "utilyt" folder. 

Check out the [library specification](https://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5:-Library-specification) for more details. 